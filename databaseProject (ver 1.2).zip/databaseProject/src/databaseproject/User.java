package databaseproject;

public class User 
{
    public String idNum;
    public String userType;
}
